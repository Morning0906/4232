// pages/index/index.js
Page({

  /**
   * 页面的初始数据
   */
 data: {
    imgUrls: [{
      img: "../../image/cand.jpg",
      openpath: "../../pages/cand/cand"
    },
    {
      img: "../../images/EmptyBanner.jpg",
      openpath: "../../pages/cand/cand"
    }
  ],
    server: [
      {
        img: "../../image/jisuanqi.jpg",
        openpath: "../../pages/calculator-index/index",
        text: "计算器"
      },
      {
        img: "../../images/yhk.png",
        openpath: "../../pages/wxyj/wxyj",
        text: "五险一金"
      },
      {
        img: "../../images/gsd.png",
        openpath: "../../pages/tax/tax",
        text: "个税"
      },
      {
        img: "../../images/ip.png",
        openpath: "../../pages/mortgage/mortgage",
        text: "贷款"
      }
    ],
    unserver: [
      {
        img: "../../images/kd.png",
        openpath: "../../pages/ruzhi/ruzhi",
        text: "入职天数"
      },
      {
        img: "../../images/gj.png",
        openpath: "../../pages/backday/backday",
        text: "倒数日"
      },
      {
        img: "../../images/gjj.png",
        openpath: "../../pages/date/date",
        text: "纪念日"
      },
      {
        img: "../../images/sl.png",
        openpath: "../../pages/",
        text: ""
      },
    ],
    indicatorDots: true,
    autoplay: true,
    interval: 5000,
    duration: 1000
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})