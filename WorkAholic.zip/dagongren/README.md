# financetools
微信小程序--财务函数，房贷、五险一金计算器

- 微信小程序二维码
<div><img src="image/preview/0.jpg" width="333" alt="微信小程序二维码"/></div>

- 财务函数
<div><img src="image/preview/1.png" width="333" alt="财务函数"/></div>
<div><img src="image/preview/2.png" width="333" alt="函数详情"/></div>

- 房贷计算
<div><img src="image/preview/3.png" width="333" alt="房贷计算"/></div>
<div><img src="image/preview/4.png" width="333" alt="房贷计算结果"/></div>

- 五险一金
<div><img src="image/preview/5.png" width="333" alt="五险一金"/></div>
